<?php
// Heading
$_['heading_title']    = 'Feeds';

// Text
$_['text_success']     = 'Success: You have modified feeds!';
$_['text_list']        = 'Feed List';

// Column
$_['column_name']      = 'Product Feed Name';
$_['column_status']    = 'Status';
$_['column_action']    = 'Action';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify feeds!';