<?php
// Heading
$_['heading_title']    = 'Sagepay Server Card Management';

$_['text_extension']   = 'Extensions';
$_['text_success']     = 'Success: You have modified Sagepay Server Card Management module!';
$_['text_edit']        = 'Edit Sagepay Server Card Management Module';

// Entry
$_['entry_status']     = 'Status';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify Sagepay Server Card Management module!';